# Sugar Developer Menu
A module loadablen package which add Developer Menu shortcuts on the Profile Menu

![Sugar Developer Profile Menu](assets/images/profile_menu.png)
