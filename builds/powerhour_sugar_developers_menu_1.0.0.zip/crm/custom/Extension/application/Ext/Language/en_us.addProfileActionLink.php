<?php
$app_strings['LNK_QRR'] = 'Quick Repair and Rebuild';
$app_strings['LNK_STUDIO'] = 'Studio';
$app_strings['LBL_REPAIR'] = 'Repair';
