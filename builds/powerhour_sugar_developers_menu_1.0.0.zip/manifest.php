<?php
$manifest = array (
  'id' => 'POWERHOUR_SUGAR_DEVELOPERS_MENU',
  'name' => 'PowerHour | Sugar Developers Menu',
  'description' => 'Adds QRR, Studio and Repair links to the Profile menu',
  'version' => '1.0.0',
  'author' => 'Jeff Bickart',
  'is_uninstallable' => 'true',
  'published_date' => '2022-04-29 09:51:53',
  'type' => 'module',
  'remove_tables' => '',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '11\\.(.*?)\\.(.*?)',
      1 => '12\\.(.*?)\\.(.*?)',
      2 => '13\\.(.*?)\\.(.*?)',
      3 => '14\\.(.*?)\\.(.*?)',
      4 => '15\\.(.*?)\\.(.*?)',
      5 => '16\\.(.*?)\\.(.*?)',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'ENT',
  ),
);
$installdefs = array (
  'id' => 'POWERHOUR_SUGAR_DEVELOPERS_MENU',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/crm/custom/Extension/application/Ext/clients/base/views/profileactions/addProfileActionLink.php',
      'to' => 'custom/Extension/application/Ext/clients/base/views/profileactions/addProfileActionLink.php',
    ),
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/crm/custom/Extension/application/Ext/Language/en_us.addProfileActionLink.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
  ),
);
